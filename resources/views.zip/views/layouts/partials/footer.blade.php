 <!-- Main Footer -->
<footer class="main-footer">
	<!-- To the right -->
	<div class="pull-right hidden-xs">
  	Sistema realizado por CODEWEB y SUAVECOD
	</div>
	<!-- Default to the left -->
	<strong>Copyright &copy; {{ Carbon\Carbon::now()->year }} <a href="#">CODEWEB</a>|<a href="#">SUAVECOD</a>|</strong> Todos los derechos reservados.
</footer>